(* TODO: set the value below *)
let hours_worked = [8 ; 7; 8; 7]